ALTER TABLE `sa_mutes` ADD `passed` INTEGER NULL;

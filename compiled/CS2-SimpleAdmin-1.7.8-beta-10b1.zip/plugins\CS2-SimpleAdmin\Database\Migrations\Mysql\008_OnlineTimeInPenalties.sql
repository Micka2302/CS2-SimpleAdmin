ALTER TABLE `sa_mutes` ADD `passed` INT NULL AFTER `duration`;
